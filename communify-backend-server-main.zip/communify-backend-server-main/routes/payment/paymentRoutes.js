const express = require("express");

const router = express.Router();

const {
  createPaymentIntent,
} = require("../../controllers/payment/paymentController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-payment-intent", authenticateUser, createPaymentIntent);

module.exports = router;
