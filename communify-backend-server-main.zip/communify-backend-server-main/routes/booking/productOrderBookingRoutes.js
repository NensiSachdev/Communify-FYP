const express = require("express");

const router = express.Router();

const {
  cancelOrder,
  confirmOrRejectOrder,
  createOrder,
  getAllOrders,
  getOrderById,
} = require("../../controllers/booking/orderBookingController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-order", authenticateUser, createOrder);

router.get("/all-orders", authenticateUser, getAllOrders);

router.get("/get-order/:orderId", authenticateUser, getOrderById);

router.patch(
  "/confirm-or-reject-order/:orderId",
  authenticateUser,
  confirmOrRejectOrder
);

router.patch("/cancel-order/:orderId", authenticateUser, cancelOrder);

module.exports = router;
