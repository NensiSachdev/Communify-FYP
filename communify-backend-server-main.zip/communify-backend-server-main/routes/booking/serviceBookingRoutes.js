const express = require("express");

const router = express.Router();

const {
  createBooking,
  getAllServiceBookings,
  getServiceBookingById,
  confirmOrRejectBooking,
  cancelBooking,
} = require("../../controllers/booking/serviceBookingController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-booking", authenticateUser, createBooking);

router.get("/all-bookings", authenticateUser, getAllServiceBookings);

router.get("/get-booking/:bookingId", authenticateUser, getServiceBookingById);

router.patch(
  "/confirm-or-reject-booking/:bookingId",
  authenticateUser,
  confirmOrRejectBooking
);

router.patch("/cancel-booking/:bookingId", authenticateUser, cancelBooking);

module.exports = router;
