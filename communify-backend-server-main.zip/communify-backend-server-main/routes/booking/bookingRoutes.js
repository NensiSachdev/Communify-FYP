const express = require("express");

const router = express.Router();

const serviceBookingRouter = require("./serviceBookingRoutes");
const productOrderBookingRouter = require("./productOrderBookingRoutes");

const { SERVICE_BOOKING, PRODUCT_ORDER } = require("../../constants/Routes");

router.use(SERVICE_BOOKING, serviceBookingRouter);
router.use(PRODUCT_ORDER, productOrderBookingRouter);

module.exports = router;
