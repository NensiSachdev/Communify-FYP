const express = require("express");

const mainRouter = express.Router();

const {
  USER,
  USER_AUTH,
  INTEREST,
  EMAIL,
  COMMUNITY,
  USER_RESET_PASSWORD,
  POST,
  BOOKING,
  PAYMENT,
} = require("../constants/Routes");

const userAuthRoutes = require("./user/UserAuthRoutes");
const interestRoutes = require("./interest/InterestRoutes");
const emailRoutes = require("./email/EmailVerificationRoutes");
const communityRoutes = require("./community/CommunityRoutes");
const userResetPasswordRouter = require("./../routes/user/ResetPasswordRoutes");
const userRouter = require("./../routes/user/UserRoutes");
const dynamicPostRouter = require("./../routes/dynamic-post/DynamicPostRoutes");
const bookingRouter = require("./../routes/booking/bookingRoutes");
const paymentRouter = require("./payment/paymentRoutes");

mainRouter.use(USER_AUTH, userAuthRoutes);
mainRouter.use(INTEREST, interestRoutes);
mainRouter.use(EMAIL, emailRoutes);
mainRouter.use(COMMUNITY, communityRoutes);
mainRouter.use(USER_RESET_PASSWORD, userResetPasswordRouter);
mainRouter.use(USER, userRouter);
mainRouter.use(POST, dynamicPostRouter);
mainRouter.use(BOOKING, bookingRouter);
mainRouter.use(PAYMENT, paymentRouter);

module.exports = mainRouter;
