const express = require("express");

const router = express.Router();

const {
  createInterest,
  getAllInterests,
} = require("../../controllers/interest/InterestController");

router.post("/create-interest", createInterest);
router.get("/all-interests", getAllInterests);

module.exports = router;
