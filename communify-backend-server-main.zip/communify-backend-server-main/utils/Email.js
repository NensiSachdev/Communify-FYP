const nodemailer = require("nodemailer");
const {
  serviceBookingTypes,
  productOrderTypes,
} = require("../constants/Basic");

const sendVerificationOtpEmail = (email, otp) => {
  return new Promise((resolve, reject) => {
    let transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      service: process.env.EMAIL_SERVICE,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_AUTH_USER,
        pass: process.env.EMAIL_AUTH_PASS,
      },
    });

    let mailOptions = {
      from: `NO-REPLY ${process.env.EMAIL_AUTH_USER}`,
      to: email,
      subject: "Email Verification OTP for Communify Account",
      html: `<h1>${otp}</h1>`,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log("Email sending error: ", error);
        reject(error);
      } else {
        console.log("Email sent: ", info.response);
        resolve(info);
      }
    });
  });
};

const sendForgotPasswordOtpEmail = (email, otp) => {
  return new Promise((resolve, reject) => {
    let transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      service: process.env.EMAIL_SERVICE,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_AUTH_USER,
        pass: process.env.EMAIL_AUTH_PASS,
      },
    });

    let mailOptions = {
      from: `NO-REPLY ${process.env.EMAIL_AUTH_USER}`,
      to: email,
      subject: "Password Reset OTP for Communify Account",
      html: `<h1>${otp}</h1>`,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log("Email sending error: ", error);
        reject(error);
      } else {
        console.log("Email sent: ", info.response);
        resolve(info);
      }
    });
  });
};

const sendServiceStatusEmail = (
  email,
  status,
  bookingId,
  bookingDateTime,
  cancellationReason = ""
) => {
  return new Promise((resolve, reject) => {
    let transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      service: process.env.EMAIL_SERVICE,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_AUTH_USER,
        pass: process.env.EMAIL_AUTH_PASS,
      },
    });

    let subject;
    let htmlContent;

    // Convert ISO date to locale string
    let formattedDateTime = new Date(bookingDateTime).toLocaleString();

    if (status === serviceBookingTypes.CONFIRMED) {
      subject = "Your Service has been Confirmed";
      htmlContent = `<p>Dear user,</p>
                     <p>We are pleased to inform you that your service request has been confirmed.</p>
                     <p><strong>Booking ID:</strong> ${bookingId}</p>
                     <p><strong>Date & Time of Booking:</strong> ${formattedDateTime}</p>
                     <p>Thank you for choosing our service.</p>`;
    } else if (status === serviceBookingTypes.REJECTED) {
      subject = "Your Service has been Rejected";
      htmlContent = `<p>Dear user,</p>
                     <p>We regret to inform you that your service request has been rejected.</p>
                     <p><strong>Booking ID:</strong> ${bookingId}</p>
                     <p><strong>Date & Time of Booking:</strong> ${formattedDateTime}</p>
                     <p>Please contact support for further assistance.</p>`;
    } else if (status === serviceBookingTypes.CANCELLED) {
      subject = "Your Service has been Canceled";
      htmlContent = `<p>Dear user,</p>
                     <p>We regret to inform you that your service request has been canceled.</p>
                     <p><strong>Booking ID:</strong> ${bookingId}</p>
                     <p><strong>Date & Time of Booking:</strong> ${formattedDateTime}</p>
                     <p><strong>Reason for Cancellation:</strong> ${cancellationReason}</p>
                     <p>Please contact support for further assistance.</p>`;
    }

    let mailOptions = {
      from: `NO-REPLY ${process.env.EMAIL_AUTH_USER}`,
      to: email,
      subject: subject,
      html: htmlContent,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log("Email sending error: ", error);
        reject(error);
      } else {
        console.log("Email sent: ", info.response);
        resolve(info);
      }
    });
  });
};

const sendProductOrderStatusEmail = (
  email,
  status,
  orderId,
  orderDateTime,
  cancellationReason = ""
) => {
  return new Promise((resolve, reject) => {
    let transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      service: process.env.EMAIL_SERVICE,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_AUTH_USER,
        pass: process.env.EMAIL_AUTH_PASS,
      },
    });

    let subject;
    let htmlContent;

    // Convert ISO date to locale string
    let formattedDateTime = new Date(orderDateTime).toLocaleString();

    if (status === productOrderTypes.CONFIRMED) {
      subject = "Your Product Order has been Confirmed";
      htmlContent = `<p>Dear customer,</p>
                     <p>We are pleased to inform you that your product order has been confirmed.</p>
                     <p><strong>Order ID:</strong> ${orderId}</p>
                     <p><strong>Date & Time of Order:</strong> ${formattedDateTime}</p>
                     <p>Thank you for shopping with us.</p>`;
    } else if (status === productOrderTypes.REJECTED) {
      subject = "Your Product Order has been Rejected";
      htmlContent = `<p>Dear customer,</p>
                     <p>We regret to inform you that your product order has been rejected.</p>
                     <p><strong>Order ID:</strong> ${orderId}</p>
                     <p><strong>Date & Time of Order:</strong> ${formattedDateTime}</p>
                     <p>Please contact support for further assistance.</p>`;
    } else if (status === productOrderTypes.CANCELLED) {
      subject = "Your Product Order has been Canceled";
      htmlContent = `<p>Dear customer,</p>
                     <p>We regret to inform you that your product order has been canceled.</p>
                     <p><strong>Order ID:</strong> ${orderId}</p>
                     <p><strong>Date & Time of Order:</strong> ${formattedDateTime}</p>
                     <p><strong>Reason for Cancellation:</strong> ${cancellationReason}</p>
                     <p>Please contact support for further assistance.</p>`;
    }

    let mailOptions = {
      from: `NO-REPLY ${process.env.EMAIL_AUTH_USER}`,
      to: email,
      subject: subject,
      html: htmlContent,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log("Email sending error: ", error);
        reject(error);
      } else {
        console.log("Email sent: ", info.response);
        resolve(info);
      }
    });
  });
};

module.exports = {
  sendVerificationOtpEmail,
  sendForgotPasswordOtpEmail,
  sendServiceStatusEmail,
  sendProductOrderStatusEmail,
};
