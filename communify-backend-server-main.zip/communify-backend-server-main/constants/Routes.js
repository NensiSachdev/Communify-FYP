const version = "v1";
module.exports = {
  USER: `/${version}/user`,
  INTEREST: `/${version}/interest`,
  USER_AUTH: `/${version}/auth/user`,
  EMAIL: `/${version}/email`,
  COMMUNITY: `/${version}/community`,
  USER_RESET_PASSWORD: `/${version}/user/reset-password`,
  POST: `/${version}/post`,
  BOOKING: `/${version}/booking`,
  SERVICE_BOOKING: "/service-booking",
  PAYMENT: `/${version}/payment`,
  PRODUCT_ORDER: "/product-order",
};
