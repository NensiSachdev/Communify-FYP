const mongoose = require("mongoose");

const { postTypesEnum, serviceTypesEnum } = require("../constants/Basic");

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    type: { type: String, enum: postTypesEnum, required: true }, // This field will be used to discriminate between post types
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      default: null,
    },
    community: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Community",
      required: false,
      default: null,
    },
    images: [
      {
        url: {
          type: String,
          required: false,
          default: "",
        },
        public_id: {
          type: String,
          required: false,
          default: "",
        },
      },
    ],
    // Add any other common fields here
  },
  { timestamps: true }
);

const productPostSchema = new mongoose.Schema(
  {
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
  },
  { discriminatorKey: "type" }
);

const ideaPostSchema = new mongoose.Schema(
  {
    upVotedUsers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: false,
        default: null,
      },
    ],
    downVotedUsers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: false,
        default: null,
      },
    ],
    totalUpVotes: { type: Number, default: 0 },
    totalDownVotes: { type: Number, default: 0 },
  },
  { discriminatorKey: "type" }
);

const servicePostSchema = new mongoose.Schema(
  {
    serviceType: { type: String, enum: serviceTypesEnum, required: true },
  },
  { discriminatorKey: "type" }
);

const eventPostSchema = new mongoose.Schema(
  {
    date: { type: Date, required: true },
    location: { type: String, required: true },
    interestedUsers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: false,
        default: null,
      },
    ],
    notInterestedUsers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: false,
        default: null,
      },
    ],
    totalInterested: { type: Number, default: 0 },
    totalNotInterested: { type: Number, default: 0 },
  },
  { discriminatorKey: "type" }
);

const Post = mongoose.model("Post", postSchema);
const ProductPost = Post.discriminator("ProductPost", productPostSchema);
const IdeaPost = Post.discriminator("IdeaPost", ideaPostSchema);
const ServicePost = Post.discriminator("ServicePost", servicePostSchema);
const EventPost = Post.discriminator("EventPost", eventPostSchema);

module.exports = { Post, ProductPost, IdeaPost, ServicePost, EventPost };
