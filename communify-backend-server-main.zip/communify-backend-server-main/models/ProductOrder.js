const mongoose = require("mongoose");
const {
  productOrderTypesEnum,
  productOrderTypes,
} = require("../constants/Basic");

const orderSchema = new mongoose.Schema(
  {
    bookedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      default: null,
    },
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post",
      required: false,
      default: null,
    },
    postOwner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      default: null,
    },
    shippingDetails: {
      city: {
        type: String,
        required: false,
        default: "",
      },
      country: {
        type: String,
        required: false,
        default: "",
      },
      area: {
        type: String,
        required: false,
        default: "",
      },
      zipCode: {
        type: String,
        required: false,
        default: "",
      },
      address: {
        type: String,
        required: false,
        default: "",
      },
    },
    status: {
      type: String,
      enum: productOrderTypesEnum,
      default: productOrderTypes.PENDING,
    },
    total: {
      type: Number,
      required: false,
      default: 0,
    },
    subTotal: {
      type: Number,
      required: false,
      default: 0,
    },
    shippingCharges: {
      type: Number,
      required: false,
      default: 200,
    },
    quantity: {
      type: Number,
      required: false,
      default: 0,
    },
    reason: {
      type: String,
      default: "N/A",
      required: false,
    },
  },
  { timestamps: true }
);

const Order = mongoose.model("Order", orderSchema);

module.exports = Order;
