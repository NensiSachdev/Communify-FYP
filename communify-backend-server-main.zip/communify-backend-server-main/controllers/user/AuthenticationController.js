const User = require("../../models/User");
const {
  STATUS_CODE,
  STATUS_MESSAGES,
  ACCOUNT_STATUS,
} = require("../../constants/Status");
const {
  ERROR_MESSAGES,
  UNAUTHORIZE_MESSAGES,
} = require("../../constants/Errors");
const { regex } = require("../../utils/Regex");
const bcrypt = require("bcrypt");
const { SUCCESS_MESSAGES } = require("../../constants/Success");
const { generateAuthenticationToken } = require("../../utils/JwtManagement");
const { generateRandomUsername } = require("../../utils/Basic");
const {
  deleteImageFromCloudinary,
  uploadImageToCloudinary,
} = require("../../utils/Cloudinary");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");

const loginUser = async (req, res) => {
  try {
    const { emailAddress, password } = req.body;

    const requiredFields = ["emailAddress", "password"];

    if (requiredFields.some((field) => !req.body[field])) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    var isValidEmail = regex.email.test(emailAddress);

    if (!isValidEmail) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(ServerErrorResponse.badRequest(ERROR_MESSAGES.INVALID_EMAIL));
    }

    const user = await User.findOne({
      emailAddress: emailAddress,
    });

    if (!user) {
      return res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.FAILED,
            STATUS_CODE.NOT_FOUND,
            ERROR_MESSAGES.USER_CREDENTIALS_NOT_FOUND,
            null
          )
        );
    }

    if (!user.isActive) {
      return res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.ERROR,
            STATUS_CODE.UNAUTHORIZED,
            UNAUTHORIZE_MESSAGES.INACTIVE_ACCOUNT,
            null
          )
        );
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.FAILED,
            STATUS_CODE.UNAUTHORIZED,
            ERROR_MESSAGES.INVALID_LOGIN_CREDENTIALS,
            null
          )
        );
    }

    var tokenPayload = {
      userId: user._id,
      firstName: user.firstName,
      lastName: user.lastName,
      profileImage: user.profileImage,
    };

    const authToken = await generateAuthenticationToken(tokenPayload);
    user.password = null;
    var responseData = {
      user: user,
      authToken: authToken,
    };

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.LOGIN_SUCCESSFUL,
          responseData
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const registerUser = async (req, res) => {
  // try {
  const requiredFields = [
    "emailAddress",
    "password",
    "firstName",
    "lastName",
    "phoneNo",
    "preferences",
  ];

  if (requiredFields.some((field) => !req.body[field])) {
    return res
      .status(STATUS_CODE.BAD_REQUEST)
      .json(
        ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
      );
  }

  const {
    emailAddress,
    password,
    firstName,
    lastName,
    phoneNo,
    isProfileImageSelected,
    profileImageBase64,
    preferences,
  } = req.body;

  const userExists = await User.findOne({
    emailAddress: emailAddress,
  });

  if (userExists) {
    return res
      .status(STATUS_CODE.CONFLICT)
      .json(
        ServerErrorResponse.customError(
          STATUS_MESSAGES.CONFLICT,
          STATUS_CODE.CONFLICT,
          ERROR_MESSAGES.USER_ALREADY_EXISTS("User"),
          null
        )
      );
  }

  if (isProfileImageSelected) {
    const cloudinaryResult = await uploadImageToCloudinary(
      profileImageBase64,
      "profiles"
    ).catch((error) => {
      console.log("cloud error: ", error);
    });

    console.log("cloudinaryResult: ", cloudinaryResult);

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const generatedUserName = generateRandomUsername();

    const user = new User({
      username: generatedUserName,
      emailAddress,
      firstName,
      lastName,
      phoneNo,
      password: hashedPassword,
      profileImage: {
        url: cloudinaryResult.secure_url,
        public_id: cloudinaryResult.public_id,
        isUploaded: true,
      },
      preferences,
      isActive: true,
    });

    const savedUser = await user.save();

    res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          SUCCESS_MESSAGES.CREATED,
          savedUser
        )
      );
  } else {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const generatedUserName = generateRandomUsername();
    // Create a new user object
    const user = new User({
      username: generatedUserName,
      emailAddress,
      firstName,
      lastName,
      phoneNo,
      password: hashedPassword,
      profileImage: {
        url: "",
        public_id: "",
        isUploaded: false,
      },
      preferences,
      isActive: true,
    });

    const savedUser = await user.save();

    res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          SUCCESS_MESSAGES.CREATED,
          savedUser
        )
      );
  }
  // } catch (error) {
  //   res
  //     .status(STATUS_CODE.SERVER_ERROR)
  //     .json(
  //       ServerErrorResponse.customErrorWithStackTrace(
  //         false,
  //         STATUS_CODE.SERVER_ERROR,
  //         STATUS_MESSAGES.SERVER_ERROR,
  //         error.stack
  //       )
  //     );
  // }
};

module.exports = {
  loginUser,
  registerUser,
};
