const {
  Post,
  ProductPost,
  IdeaPost,
  ServicePost,
  EventPost,
} = require("../../models/DynamicPost");
const {
  deleteImageFromCloudinary,
  uploadImageToCloudinary,
} = require("../../utils/Cloudinary");
const {
  STATUS_CODE,
  STATUS_MESSAGES,
  ACCOUNT_STATUS,
} = require("../../constants/Status");
const {
  ERROR_MESSAGES,
  UNAUTHORIZE_MESSAGES,
} = require("../../constants/Errors");
const { SUCCESS_MESSAGES } = require("../../constants/Success");

const { postTypes, serviceTypes } = require("../../constants/Basic");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");

const createPost = async (req, res) => {
  const currentUser = req.user;
  const requiredFields = [
    "title",
    "description",
    "images",
    "type",
    "communityId",
  ];

  if (requiredFields.some((field) => !req.body[field])) {
    return res
      .status(STATUS_CODE.BAD_REQUEST)
      .json(
        ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
      );
  }
  const { title, description, type, images, communityId } = req.body;

  const cloudinaryUploads = await Promise.all(
    images.map(async (base64Image) => {
      return await uploadImageToCloudinary(base64Image);
    })
  );

  const imageDetails = cloudinaryUploads.map((result) => ({
    url: result.secure_url,
    public_id: result.public_id,
  }));

  try {
    let newPost;

    switch (type) {
      case "PRODUCT":
        newPost = new ProductPost({
          title,
          description,
          type,
          user: currentUser._id,
          images: imageDetails,
          price: req.body.price,
          quantity: req.body.quantity,
          community: communityId,
        });
        break;
      case "IDEA":
        newPost = new IdeaPost({
          title,
          description,
          type,
          user: currentUser._id,
          images: imageDetails,
          community: communityId,
        });
        break;
      case "SERVICE":
        newPost = new ServicePost({
          title,
          description,
          type,
          user: currentUser._id,
          images: imageDetails,
          serviceType: req.body.serviceType,
          community: communityId,
        });
        break;
      case "EVENT":
        newPost = new EventPost({
          title,
          description,
          type,
          user: currentUser._id,
          images: imageDetails,
          organizer: req.body.organizer,
          date: req.body.date,
          location: req.body.location,
          community: communityId,
        });
        break;
      default:
        return res.status(400).json({ message: "Invalid post type" });
    }

    const savedPost = await newPost.save();

    return res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          SUCCESS_MESSAGES.CREATED,
          savedPost
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getAllPosts = async (req, res) => {
  try {
    const allPosts = await Post.find()
      .populate("user") // Populate the 'user' field in the base post schema
      .populate("community") // Populate the 'community' field in the base post schema
      .populate({
        path: "upVotedUsers",
        model: "User", // Populate the 'upVotedUsers' field in the IdeaPost schema
      })
      .populate({
        path: "downVotedUsers",
        model: "User", // Populate the 'downVotedUsers' field in the IdeaPost schema
      });

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          allPosts
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getSinglePost = async (req, res) => {
  const postId = req.params.postId;

  try {
    const post = await Post.findById(postId)
      .populate("user") // Populate the 'user' field in the base post schema
      .populate("community") // Populate the 'community' field in the base post schema
      .populate({
        path: "upVotedUsers",
        model: "User", // Populate the 'upVotedUsers' field in the IdeaPost schema
      })
      .populate({
        path: "downVotedUsers",
        model: "User", // Populate the 'downVotedUsers' field in the IdeaPost schema
      });

    if (!post) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.POST_NOT_FOUND));
    }

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          post
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const deletePost = async (req, res) => {
  try {
    const postId = req.params.postId;
    const currentUser = req.user; // Assuming user information is attached to the request

    const post = await Post.findById(postId);

    if (!post) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.POST_NOT_FOUND));
    }

    // Check if the post belongs to the logged-in user
    if (post.user.toString() !== currentUser._id.toString()) {
      return res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.unauthorized(
            ERROR_MESSAGES.UNAUTHORIZED_DELETE_POST
          )
        );
    }

    // Delete post images from Cloudinary
    const deletedImages = await Promise.all(
      post.images.map(async (image) => {
        await deleteImageFromCloudinary(image.public_id);
      })
    );

    const deletedPost = await Post.findByIdAndDelete(post._id);

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.DELETE,
          deletedPost
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const updatePost = async (req, res) => {
  try {
    const postId = req.params.postId;
    const currentUser = req.user;
    const requiredFields = ["title", "description", "type"];

    if (requiredFields.some((field) => !req.body[field])) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }
    const { title, description, type } = req.body;

    const post = await Post.findById(postId);

    if (!post) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.POST_NOT_FOUND));
    }

    if (post.user.toString() !== currentUser._id.toString()) {
      return res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.unauthorized(
            ERROR_MESSAGES.UNAUTHORIZED_UPDATE_POST
          )
        );
    }

    post.title = title;
    post.description = description;

    switch (type) {
      case "PRODUCT":
        post.price = req.body.price;
        post.quantity = req.body.quantity;
        break;
      case "IDEA":
        break;
      case "SERVICE":
        post.serviceType = req.body.serviceType;
        break;
      case "EVENT":
        post.organizer = req.body.organizer;
        post.date = req.body.date;
        post.location = req.body.location;
        break;
      default:
        return res
          .status(STATUS_CODE.BAD_REQUEST)
          .json(
            ServerErrorResponse.badRequest(ERROR_MESSAGES.INVALID_POST_TYPE)
          );
    }

    const updatedPost = await post.save();

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          updatedPost
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getAllPostTypes = async (req, res) => {
  try {
    const transformedArray = postTypes;
    if (!transformedArray || transformedArray.length <= 0) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(
          ServerErrorResponse.notFound(ERROR_MESSAGES.POST_TYPES_NOT_FOUND)
        );
    }

    return res.status(STATUS_CODE.OK).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.OK,
        SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
        {
          postTypes: transformedArray,
        }
      )
    );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getAllServiceTypes = async (req, res) => {
  try {
    const transformedArray = serviceTypes;
    if (!transformedArray || transformedArray.length <= 0) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(
          ServerErrorResponse.notFound(ERROR_MESSAGES.SERVICE_TYPES_NOT_FOUND)
        );
    }

    return res.status(STATUS_CODE.OK).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.OK,
        SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
        {
          serviceTypes: transformedArray,
        }
      )
    );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getPostsForUser = async (req, res) => {
  const userId = req.user._id; // Assuming user information is attached to the request

  try {
    // Find posts where the user is the creator
    const creatorPosts = await Post.find({ user: userId })
      .populate("user")
      .populate("community")
      .populate({
        path: "upVotedUsers",
        model: "User",
      })
      .populate({
        path: "downVotedUsers",
        model: "User",
      });

    // Find posts where the user is a member
    const memberPosts = await Post.find({
      community: { $elemMatch: { users: userId } },
    })
      .populate("user")
      .populate("community")
      .populate({
        path: "upVotedUsers",
        model: "User",
      })
      .populate({
        path: "downVotedUsers",
        model: "User",
      });

    const allUserPosts = [...creatorPosts, ...memberPosts];

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          allUserPosts
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getAllCommmunityPosts = async (req, res) => {
  try {
    const communityId = req.params.communityId;
    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }
    const allPosts = await Post.find({
      community: communityId,
    })
      .populate("user") // Populate the 'user' field in the base post schema
      .populate("community") // Populate the 'community' field in the base post schema
      .populate({
        path: "upVotedUsers",
        model: "User", // Populate the 'upVotedUsers' field in the IdeaPost schema
      })
      .populate({
        path: "downVotedUsers",
        model: "User", // Populate the 'downVotedUsers' field in the IdeaPost schema
      });

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          allPosts
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const updateIdeaPostVotes = async (req, res) => {
  try {
    const currentUser = req.user;
    const { ideaPostId } = req.params;
    const { voteType } = req.body;

    const ideaPost = await IdeaPost.findById(ideaPostId);

    if (!ideaPost) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.POST_NOT_FOUND));
    }

    const alreadyUpvoted = ideaPost.upVotedUsers.some(
      (user) => user.toString() === currentUser._id.toString()
    );
    const alreadyDownvoted = ideaPost.downVotedUsers.some(
      (user) => user.toString() === currentUser._id.toString()
    );

    if (voteType === "UPVOTE") {
      if (alreadyUpvoted) {
        ideaPost.upVotedUsers = ideaPost.upVotedUsers.filter(
          (user) => user.toString() !== currentUser._id.toString()
        );
      } else {
        if (alreadyDownvoted) {
          ideaPost.downVotedUsers = ideaPost.downVotedUsers.filter(
            (user) => user.toString() !== currentUser._id.toString()
          );
        }
        ideaPost.upVotedUsers.push(currentUser._id);
      }
    } else if (voteType === "DOWNVOTE") {
      if (alreadyDownvoted) {
        ideaPost.downVotedUsers = ideaPost.downVotedUsers.filter(
          (user) => user.toString() !== currentUser._id.toString()
        );
      } else {
        if (alreadyUpvoted) {
          ideaPost.upVotedUsers = ideaPost.upVotedUsers.filter(
            (user) => user.toString() !== currentUser._id.toString()
          );
        }
        ideaPost.downVotedUsers.push(currentUser._id);
      }
    } else {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(ServerErrorResponse.badRequest("Invalid vote type"));
    }

    ideaPost.totalUpVotes = ideaPost.upVotedUsers.length;
    ideaPost.totalDownVotes = ideaPost.downVotedUsers.length;

    await ideaPost.save();

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          ideaPost
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(ServerErrorResponse.internal(error));
  }
};

const updateEventPostInterest = async (req, res) => {
  try {
    const currentUser = req.user;
    const { eventPostId } = req.params;
    const { interestType } = req.body;

    const eventPost = await EventPost.findById(eventPostId);

    if (!eventPost) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.POST_NOT_FOUND));
    }

    const alreadyInterested = eventPost.interestedUsers.some(
      (user) => user.toString() === currentUser._id.toString()
    );
    const alreadyNotInterested = eventPost.notInterestedUsers.some(
      (user) => user.toString() === currentUser._id.toString()
    );

    if (interestType === "INTERESTED") {
      if (alreadyInterested) {
        eventPost.interestedUsers = eventPost.interestedUsers.filter(
          (user) => user.toString() !== currentUser._id.toString()
        );
      } else {
        if (alreadyNotInterested) {
          eventPost.notInterestedUsers = eventPost.notInterestedUsers.filter(
            (user) => user.toString() !== currentUser._id.toString()
          );
        }
        // Add the interest
        eventPost.interestedUsers.push(currentUser._id);
      }
    } else if (interestType === "NOT_INTERESTED") {
      if (alreadyNotInterested) {
        eventPost.notInterestedUsers = eventPost.notInterestedUsers.filter(
          (user) => user.toString() !== currentUser._id.toString()
        );
      } else {
        if (alreadyInterested) {
          eventPost.interestedUsers = eventPost.interestedUsers.filter(
            (user) => user.toString() !== currentUser._id.toString()
          );
        }
        eventPost.notInterestedUsers.push(currentUser._id);
      }
    } else {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(ServerErrorResponse.badRequest("Invalid interest type"));
    }

    eventPost.totalInterested = eventPost.interestedUsers.length;
    eventPost.totalNotInterested = eventPost.notInterestedUsers.length;

    await eventPost.save();

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          eventPost
        )
      );
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(ServerErrorResponse.internal(error));
  }
};

module.exports = {
  createPost,
  getAllPosts,
  getSinglePost,
  deletePost,
  updatePost,
  getAllPostTypes,
  getAllServiceTypes,
  getPostsForUser,
  getAllCommmunityPosts,
  updateIdeaPostVotes,
  updateEventPostInterest,
};
