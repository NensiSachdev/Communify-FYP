const Order = require("../../models/ProductOrder");
const { Post } = require("../../models/DynamicPost");
const { STATUS_CODE, STATUS_MESSAGES } = require("../../constants/Status");
const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");
const { productOrderTypes } = require("../../constants/Basic");
const { sendProductOrderStatusEmail } = require("../../utils/Email");

const createOrder = async (req, res) => {
  try {
    const { postId, shippingDetails, quantity, total } = req.body;
    const userId = req.user._id;

    const post = await Post.findById(postId);
    if (!post) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Post not found."));
    }

    if (quantity > post.quantity) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(
            "Ordered quantity exceeds available quantity."
          )
        );
    }

    post.quantity -= quantity;
    await post.save();

    const order = new Order({
      bookedBy: userId,
      post: post._id,
      postOwner: post.user,
      shippingDetails,
      quantity,
      total: total + 200,
      shippingCharges: 200,
      subTotal: total,
    });

    const savedOrder = await order.save();

    res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          "Product order has been created successfully.",
          savedOrder
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const getAllOrders = async (req, res) => {
  try {
    const currentUser = req.user;

    const ordersMadeByUser = await Order.find({
      bookedBy: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    const ordersMadeForUser = await Order.find({
      postOwner: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    res.status(STATUS_CODE.OK).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.OK,
        "Orders found",
        {
          ordersMadeByUser,
          ordersMadeForUser,
        }
      )
    );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const getOrderById = async (req, res) => {
  try {
    const { orderId } = req.params;

    const singleOrder = await Order.findById(orderId)
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    if (!singleOrder) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Product order not found!"));
    }

    res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          "Order found",
          singleOrder
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const confirmOrRejectOrder = async (req, res) => {
  try {
    const { orderId } = req.params;

    if (!orderId || orderId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(ServerErrorResponse.badRequest("Order ID is required."));
    }

    const order = await Order.findById(orderId).populate("bookedBy");
    if (!order) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Product order not found"));
    }

    const { status } = req.body;

    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      { status },
      { new: true }
    );

    await sendProductOrderStatusEmail(
      order.bookedBy.emailAddress,
      status,
      order._id,
      order.createdAt,
      ""
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          "Order status updated successfully.",
          updatedOrder
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const cancelOrder = async (req, res) => {
  try {
    const { orderId } = req.params;

    if (!orderId || orderId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(ServerErrorResponse.badRequest("Order ID is required."));
    }

    const { reason } = req.body;

    const order = await Order.findById(orderId).populate("postOwner");
    if (!order) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Product order not found"));
    }

    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      {
        status: productOrderTypes.CANCELLED,
        reason,
      },
      { new: true }
    );

    await sendProductOrderStatusEmail(
      order.postOwner.emailAddress,
      productOrderTypes.CANCELLED,
      order._id,
      order.createdAt,
      reason
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          "Order cancelled successfully.",
          updatedOrder
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

module.exports = {
  createOrder,
  getAllOrders,
  getOrderById,
  confirmOrRejectOrder,
  cancelOrder,
};
