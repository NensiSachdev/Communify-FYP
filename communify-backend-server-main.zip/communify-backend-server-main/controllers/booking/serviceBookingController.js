const ServiceBooking = require("../../models/ServiceBooking");
const { ServicePost, Post } = require("../../models/DynamicPost");
const { STATUS_CODE, STATUS_MESSAGES } = require("../../constants/Status");
const { ERROR_MESSAGES } = require("../../constants/Errors");
const { SUCCESS_MESSAGES } = require("../../constants/Success");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");
const { serviceBookingTypes } = require("../../constants/Basic");
const { sendServiceStatusEmail } = require("../../utils/Email");

const createBooking = async (req, res) => {
  try {
    const { servicePostId, bookingDate } = req.body;
    const userId = req.user._id;

    const servicePost = await Post.findById(servicePostId);
    if (!servicePost) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Service post not found."));
    }

    const booking = new ServiceBooking({
      bookedBy: userId,
      post: servicePost._id,
      bookingDate,
      postOwner: servicePost.user,
    });

    const savedBooking = await booking.save();

    res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          "Service has been booked sucessfully.",
          savedBooking
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const getAllServiceBookings = async (req, res) => {
  try {
    const currentUser = req.user;

    const bookingsMadeByUser = await ServiceBooking.find({
      bookedBy: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    const bookingsMadeForUser = await ServiceBooking.find({
      postOwner: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    res.status(STATUS_CODE.OK).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.OK,
        "Bookings found",
        {
          bookingsMadeByUser,
          bookingsMadeForUser,
        }
      )
    );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const getServiceBookingById = async (req, res) => {
  try {
    const currentUser = req.user;
    const { bookingId } = req.params;

    const singleBooking = await ServiceBooking.findById(bookingId)
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    if (!singleBooking) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Service booking not found!"));
    }

    res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          "Booking found",
          singleBooking
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const confirmOrRejectBooking = async (req, res) => {
  try {
    const currentUser = req.user;
    const bookingId = req.params.bookingId;

    if (!bookingId || bookingId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const serviceBooking = await ServiceBooking.findById(bookingId).populate(
      "bookedBy"
    );
    if (!serviceBooking) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Service booking not found"));
    }

    const { status } = req.body;

    const filter = {
      _id: serviceBooking._id,
    };

    const updatedData = {
      status,
    };

    const updatedServiceBooking = await ServiceBooking.findByIdAndUpdate(
      filter,
      updatedData,
      {
        new: true,
      }
    );

    await sendServiceStatusEmail(
      serviceBooking.bookedBy.emailAddress,
      status,
      serviceBooking._id,
      serviceBooking.bookingDate,
      ""
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          null
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const cancelBooking = async (req, res) => {
  try {
    const currentUser = req.user;
    const bookingId = req.params.bookingId;

    if (!bookingId || bookingId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const { reason } = req.body;

    const serviceBooking = await ServiceBooking.findById(bookingId).populate(
      "postOwner"
    );
    if (!serviceBooking) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Service booking not found"));
    }

    const filter = {
      _id: serviceBooking._id,
    };

    const updatedData = {
      status: serviceBookingTypes.CANCELLED,
      reason,
    };

    const updatedServiceBooking = await ServiceBooking.findByIdAndUpdate(
      filter,
      updatedData,
      {
        new: true,
      }
    );

    await sendServiceStatusEmail(
      serviceBooking.postOwner.emailAddress,
      serviceBookingTypes.CANCELLED,
      serviceBooking._id,
      serviceBooking.bookingDate,
      reason
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          null
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

module.exports = {
  createBooking,
  getAllServiceBookings,
  getServiceBookingById,
  confirmOrRejectBooking,
  cancelBooking,
};
