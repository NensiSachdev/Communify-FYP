const Community = require("../../models/Community");
const User = require("../../models/User");
const { STATUS_CODE, STATUS_MESSAGES } = require("../../constants/Status");
const { ERROR_MESSAGES } = require("../../constants/Errors");
const { regex } = require("../../utils/Regex");
const { SUCCESS_MESSAGES } = require("../../constants/Success");
const {
  deleteImageFromCloudinary,
  uploadImageToCloudinary,
} = require("../../utils/Cloudinary");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");

const createCommunity = async (req, res) => {
  try {
    const currentUser = req.user;

    const requiredFields = [
      "title",
      "description",
      "interests",
      "coverImageBase64",
    ];

    if (requiredFields.some((field) => !req.body[field])) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const {
      title,
      description,
      interests,
      isCoverImageSelected,
      coverImageBase64,
    } = req.body;

    const community = await Community.findOne({
      title: title,
    });

    if (community) {
      res
        .status(STATUS_CODE.NOT_FOUND)
        .json(
          ServerErrorResponse.notFound(
            "A community already exists with the provided title."
          )
        );
    }

    if (isCoverImageSelected) {
      const cloudinaryResult = await uploadImageToCloudinary(
        coverImageBase64,
        "community-covers"
      );

      const community = new Community({
        title,
        description,
        creator: currentUser._id,
        coverImage: {
          url: cloudinaryResult.secure_url,
          public_id: cloudinaryResult.public_id,
          isUploaded: true,
        },
        interests,
        isActive: true,
      });

      const savedCommunity = await community.save();

      res
        .status(STATUS_CODE.CREATED)
        .json(
          ServerSuccessResponse.successResponse(
            true,
            STATUS_MESSAGES.SUCCESS,
            STATUS_CODE.CREATED,
            "New community created.",
            savedCommunity
          )
        );
    } else {
      const community = new Community({
        title,
        description,
        creator: currentUser._id,
        coverImage: {
          url: "",
          public_id: "",
          isUploaded: false,
        },
        interests,
        isActive: true,
      });

      const savedCommunity = await community.save();

      res
        .status(STATUS_CODE.CREATED)
        .json(
          ServerSuccessResponse.successResponse(
            true,
            STATUS_MESSAGES.SUCCESS,
            STATUS_CODE.CREATED,
            "New community created.",
            savedCommunity
          )
        );
    }
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getAllCommunities = async (req, res) => {
  try {
    const currentUser = req.user;

    const allCommunities = await Community.find({
      isActive: true,
      $nor: [
        { creator: currentUser._id }, // Exclude communities where the user is the creator
        { users: currentUser._id }, // Exclude communities where the user is a member
      ],
    })
      .populate("interests")
      .populate("users");

    if (allCommunities.length <= 0) {
      res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("No communities available!"));
    } else {
      res
        .status(STATUS_CODE.OK)
        .json(
          ServerSuccessResponse.successResponse(
            true,
            STATUS_MESSAGES.SUCCESS,
            STATUS_CODE.OK,
            "Communities found",
            allCommunities
          )
        );
    }
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getCommunityById = async (req, res) => {
  const { communityId } = req.params;

  try {
    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const community = await Community.findById(communityId)
      .populate("interests")
      .populate("users");

    if (!community) {
      res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Community not found!"));
    } else {
      res
        .status(STATUS_CODE.OK)
        .json(
          ServerSuccessResponse.successResponse(
            true,
            STATUS_MESSAGES.SUCCESS,
            STATUS_CODE.OK,
            "Community found",
            community
          )
        );
    }
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const deleteCommunity = async (req, res) => {
  try {
    const communityId = req.params.communityId;
    const currentUser = req.user;
    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }
    const community = await Community.findById(communityId);
    if (!community) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.COMMUNITY_NOT_FOUND));
    }

    if (community.creator.toString() !== currentUser._id.toString()) {
      return res
        .status(STATUS_CODE.FORBIDDEN)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.FAILED,
            STATUS_CODE.FORBIDDEN,
            ERROR_MESSAGES.UNAUTHORIZED_DELETE_COMMUNITY,
            null
          )
        );
    }

    const deletedCommunity = await Community.findByIdAndDelete(communityId);

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.DELETE,
          deletedCommunity
        )
      );
  } catch (error) {
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const updateCommunity = async (req, res) => {
  try {
    const communityId = req.params.communityId;
    const currentUser = req.user;
    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const requiredFields = ["title", "description", "interests"];

    if (requiredFields.some((field) => !req.body[field])) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const community = await Community.findById(communityId);
    if (!community) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.COMMUNITY_NOT_FOUND));
    }

    if (community.creator.toString() !== currentUser._id.toString()) {
      return res
        .status(STATUS_CODE.FORBIDDEN)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.FAILED,
            STATUS_CODE.FORBIDDEN,
            ERROR_MESSAGES.UNAUTHORIZED_DELETE_COMMUNITY,
            null
          )
        );
    }

    const { title, description, interests, isActive } = req.body;
    const checkCommunity = await Community.findOne({
      title: title,
      _id: { $ne: community._id },
    });

    if (checkCommunity) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.PRODUCT_ALREADY_EXISTS)
        );
    }

    const filter = {
      _id: community._id,
    };

    const updatedData = {
      title: title || community.title,
      description: description || community.description,
      isActive: isActive !== undefined ? isActive : community.isActive,
      interests: interests || community.interests,
    };

    const updatedCommunity = await Community.findByIdAndUpdate(
      filter,
      updatedData,
      {
        new: true,
      }
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.UPDATE,
          updatedCommunity
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const suggestCommunitiesForUser = async (req, res) => {
  try {
    const currentUser = req.user;

    const user = await User.findById(currentUser._id).populate("preferences");

    if (!user) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(
          ServerErrorResponse.notFound(ERROR_MESSAGES.USER_NOT_FOUND_WITH_ID)
        );
    }

    const userPreferences = user.preferences.map(
      (preference) => preference._id
    );

    const userCommunities = await Community.find({
      $or: [{ creator: currentUser._id }, { members: currentUser._id }],
    });

    const userCommunityIds = userCommunities.map((community) => community._id);

    const suggestedCommunities = await Community.find({
      interests: { $in: userPreferences },
      isActive: true,
      _id: { $nin: userCommunityIds },
    });

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          suggestedCommunities
        )
      );
  } catch (error) {
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const joinCommunity = async (req, res) => {
  try {
    const currentUser = req.user;
    const { communityId } = req.params;

    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const community = await Community.findById(communityId);

    if (!community) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.COMMUNITY_NOT_FOUND));
    }

    // Check if the user is already a member of the community
    if (community.users.includes(currentUser._id)) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(
            "You are already a member of this community."
          )
        );
    }

    // Add the user to the community's members array
    community.users.push(currentUser._id);
    await community.save();

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          community
        )
      );
  } catch (error) {
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const leaveCommunity = async (req, res) => {
  try {
    const currentUser = req.user;
    const { communityId } = req.params;

    if (!communityId || communityId === "") {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(ERROR_MESSAGES.EMPTY_REQUIRED_FIELDS)
        );
    }

    const community = await Community.findById(communityId);

    if (!community) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound(ERROR_MESSAGES.COMMUNITY_NOT_FOUND));
    }

    // Check if the user is a member of the community
    if (!community.users.includes(currentUser._id)) {
      return res
        .status(STATUS_CODE.BAD_REQUEST)
        .json(
          ServerErrorResponse.badRequest(
            "You are not a member of this community."
          )
        );
    }

    const updatedCommunity = await Community.findByIdAndUpdate(
      communityId,
      { $pull: { users: currentUser._id } },
      { new: true }
    );

    return res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          SUCCESS_MESSAGES.OPERATION_SUCCESSFULL,
          updatedCommunity
        )
      );
  } catch (error) {
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

const getUserCommunities = async (req, res) => {
  try {
    const currentUser = req.user;

    // Fetch communities created by the user
    const createdCommunities = await Community.find({
      creator: currentUser._id,
    })
      .populate("interests")
      .populate("users");

    const joinedCommunities = await Community.find({
      users: { $in: [currentUser._id] },
    })
      .populate("interests")
      .populate("users");

    // Combine the results or structure them as needed
    const userCommunities = {
      createdCommunities,
      joinedCommunities,
    };

    res
      .status(STATUS_CODE.OK)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.OK,
          "User communities found",
          userCommunities
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          false,
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error.stack
        )
      );
  }
};

module.exports = {
  createCommunity,
  getAllCommunities,
  getCommunityById,
  deleteCommunity,
  updateCommunity,
  suggestCommunitiesForUser,
  joinCommunity,
  leaveCommunity,
  getUserCommunities,
};
